<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h1 style="text-align: center">ĐƠN HÀNG SERI SINH NHẬT NGÀY <?php echo e($date); ?></h1>
    <p>Bình thân mến,</p>
    <p >Thông tin đơn hàng</p>
    <p>Tên người mua: <?php echo e($data['name']); ?></p>
    <p>Số điện thoại: <a href=""><?php echo e($data['phone']); ?></a></p>
    <p>Địa chỉ:<?php echo e($data['address']); ?></p>
    <p>Ghi chú: <?php echo e($data['note'] ?? ''); ?></p>
    <p><b>Nội dung mua:<b></p>
        <?php $__currentLoopData = $data['ifOrder']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p>Seri: <?php echo e($value['code']); ?> <?php echo e($value['seri']); ?> Mệnh giá: <?php echo e($value['displayValue']); ?> Giá: <?php echo e($value['price']); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <p>Phương thức thanh toán: <?php echo e($data['pay_method']); ?></p>
    <p>Tổng tiền: <?php echo e($total); ?></p>
</body>
</html>
<?php /**PATH C:\laragon\www\shoptiensn\backend\resources\views/sendmail.blade.php ENDPATH**/ ?>